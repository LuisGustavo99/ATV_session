<?php

session_start();

$valor = trim($_POST['valor'] ?? '');

if (isset($_SESSION['valor'])) {
    $_SESSION['_flash'] = ['erro', 'Erro: já existe um valor na sessão!'];
} elseif ($valor === '') {
    $_SESSION['_flash'] = ['erro', 'Erro: informe um valor.'];
} else {
    $_SESSION['valor'] = $valor;
    $_SESSION['_flash'] = ['ok', 'Valor criado na sessão.'];
}

header('Location: index.php');
exit;
