<?php

session_start();

$valor = trim($_POST['valor'] ?? '');

if (!isset($_SESSION['valor'])) {
    $_SESSION['_flash'] = ['erro', 'Erro: a sessão ainda não foi criada!'];
} elseif ($valor === '') {
    $_SESSION['_flash'] = ['erro', 'Erro: informe um novo valor.'];
} else {
    $_SESSION['valor'] = $valor;
    $_SESSION['_flash'] = ['ok', 'Valor da sessão alterado.'];
}

header('Location: index.php');
exit;
