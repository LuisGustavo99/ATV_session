<?php

session_start();

$flash = $_SESSION['_flash'] ?? null;
unset($_SESSION['_flash']);

$existe = isset($_SESSION['valor']);
$exibir = $existe
    ? (is_array($_SESSION['valor']) ? implode(', ', $_SESSION['valor']) : $_SESSION['valor'])
    : null;
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Atividade – Sessões PHP</title>
</head>
<body>
    <div class="caixa">
        
        <style>
           .caixa{
            text-align: center;

           } 
            
        </style>

        <h1>Sessões em PHP</h1>

<?php if ($flash): ?>
    <p><?= htmlspecialchars($flash[1]) ?></p>
    <?php endif; ?>
    
    <h2>Valor armazenado</h2>
    <p>
        <?= $existe ? htmlspecialchars((string)$exibir) : 'Sessão não existe!' ?>
    </p>
    
    <form action="criar.php" method="post">
        <input type="text" name="valor" placeholder="Valor a criar">
        <button type="submit">Criar</button>
    </form>
    
    <form action="alterar.php" method="post">
        <input type="text" name="valor" placeholder="Novo valor">
        <button type="submit">Alterar</button>
    </form>
    
    <form action="remover.php" method="post">
        <button type="submit">Remover sessão</button>
    </form>
</div>
</body>
</html>